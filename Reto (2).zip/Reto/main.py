from A01570748_M1.pagina import basic_example_space

if __name__ == "__main__":
    basic_example_space()
